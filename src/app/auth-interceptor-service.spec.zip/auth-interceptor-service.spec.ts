import { AuthInterceptorService } from './auth-interceptor-service';

describe('AuthInterceptorService', () => {
  it('should create an instance', () => {
    expect(new AuthInterceptorService()).toBeTruthy();
  });
});
